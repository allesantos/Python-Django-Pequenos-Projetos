from django.contrib import admin
from django.urls import path
from contato.views import contato

urlpatterns = [
    path('admin/', admin.site.urls),
    path('contato/', contato),
]
